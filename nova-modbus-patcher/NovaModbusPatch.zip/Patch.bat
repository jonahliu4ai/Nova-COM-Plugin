@echo off
cd /d "%~dp0"
Patcher.exe "%CD%"
pause
